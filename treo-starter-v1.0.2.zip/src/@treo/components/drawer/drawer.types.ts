export type TreoDrawerMode = 'over' | 'side';
export type TreoDrawerPosition = 'left' | 'right';
