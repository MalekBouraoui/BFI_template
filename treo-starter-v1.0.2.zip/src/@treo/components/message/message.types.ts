export type TreoMessageAppearance = 'border' | 'fill' | 'outline';
export type TreoMessageType = 'primary' | 'accent' | 'warn' | 'basic' | 'info' | 'success' | 'warning' | 'error';
