export interface TreoMockApi
{
    register(): void;
}
