export * from '@treo/services/config/config.module';
export * from '@treo/services/config/config.service';
